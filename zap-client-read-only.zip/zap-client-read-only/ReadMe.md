
Open With Kwrite To Read Easier



Features:
Legitbot - Aimbot, RCS
Ragebot - Aimbot, RCS
Triggerbot
ESP - Enemy & Teammate, Spectator List, Crosshair, Radar
MISC - Gamemode Switcher, Disable Overlay, Disable ESP, FPS Cap
Configs - Custom Configs



1. Build glfw
git clone https://github.com/glfw/glfw.git
cd glfw
mkdir build
cd build
cmake ..
make
sudo make install

2. Exit the terminal and re-open it (So that you dont build the cheat directly into the GLFW build folder, wont work otherwise. Do this Once when you install linux no need to do again unless you reset your system!)

3. Build & Run
Open Terminal in zap folder and do these commands
mkdir build
cd build
cmake ..
make
chmod +x run.sh
sudo ./run.sh

4. Press Insert to toggle the Menu (You can only interact with the Menu and the game when the menu is active). Note: You will need to alt+tab
between the cheat overlay and apex. and borderless is required.

Credits: Warachii
Credits: JLab
